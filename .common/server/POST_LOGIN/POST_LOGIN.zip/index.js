'use strict';
console.log('Loading function');
const AWS = require('aws-sdk');
const doc = require('dynamodb-doc');
const dynamo = new doc.DynamoDB();
const crypto = require('crypto');
const jwt = require('jsonwebtoken');

const encrypted = process.env['jwt_secret'];
var decrypted;

function generateJWT(event, context, callback){
    let params = {
                    Key: {
                        "public_identity_key":  event.public_identity_key
                    }, 
                    TableName: "Users"
                 };
    dynamo.getItem(params, function(err, data) {
        if (err) console.log(err, err.stack); // an error occurred
        else     console.log(data);           // successful response
    });
    
    var hdr = new Buffer(JSON.stringify(
        {
            "alg": "HS256",
            "typ": "JWT"
        })).toString('base64');
              
    var iat = new Date();
    var exp = iat + 1;
    var nbf = iat;
    
    var pay = new Buffer(JSON.stringify(
        {
            "iss": "watchmyass.webcam",//refers to issuer server
            "aud": "watchmyass.webcam",//refers to auth server, same server
            "sub":  event.public_identity_key,
            "exp":  exp, //reject exceeding
            "nbf":  nbf, //reject before
            "iat":  iat, //informational
            "jti": "unique crypto random string" //prevent replay attacks
        })).toString('base64');
              
    const hmac = crypto.createHmac('sha256', new Buffer(decrypted, 'ascii'));
    hmac.update(hdr + "." + pay);
    var sig = hmac.digest('base64');
    var jwt = hdr + '.' + pay + '.' + sig;
    callback(null, jwt);
}
/**
 * Provide an event that contains the following keys:
 *   - public_identity_key : user identifier
 */
exports.handler = (event, context, callback) => {
    console.log('Received event:', JSON.stringify(event, null, 2));
    if(decrypted) {
        generateJWT(event, context, function(err, data) {
            if(err) callback(err);
            else callback(null, data);
        })
    } else {
        const kms = new AWS.KMS();
        console.log(encrypted);
        kms.decrypt({ CiphertextBlob: new Buffer(encrypted, 'base64') }, function(err, data) {
            console.log('dsadasdas');
            if (err) {
                console.log('Decrypt error:', err);
                return callback(err);
            }
            console.log(JSON.stringify(data.Plaintext, null, 2));
            decrypted = data.Plaintext.toString('ascii'); 
            generateJWT(event, context, function(err, data) {
                if(err) callback(err);
                else callback(null, data);
            })
        });
    }
};
    
        
